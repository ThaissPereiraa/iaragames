const express = require('express');
const app = express();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY); // Use an environment variable

app.use(express.json()); // Enable JSON parsing

app.post('/charge', (req, res) => {
    const { token, amount, currency } = req.body;

  // Create a charge
    stripe.charges.create({
    amount,
    currency,
    source: token,
    description: 'Test payment',
    })
    .then((charge) => res.json(charge))
    .catch((err) => res.status(500).json({ error: err.message }));
});

app.listen(3000, () => console.log('Server listening on port 3000'));